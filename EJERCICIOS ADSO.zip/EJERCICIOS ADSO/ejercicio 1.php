<?php
$numero = 10; // Variable que nos informa el número a revisar

function determinarSigno($num) {
    if ($num > 0) {
        return "El número $num es Positivo.";
    } elseif ($num < 0) {
        return "El número $num es Negativo.";
    } else {
        return "El número es Cero."; // Se añadió el punto y coma al final
    }
}

// Llamar a la función
echo determinarSigno($numero);
?>
