<?php
// Declarar la función
function suma($a, $b) {
    // Suma de parámetros en la variable resultado
    $resultado = $a + $b;
    return $resultado;
}

// Llamar a la función y almacenar el resultado en la variable $suma
$suma = suma(5, 3);

// Mostrar el resultado
echo "El resultado de la suma de 5 y 3 es: " . $suma;
?>

