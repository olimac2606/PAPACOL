<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nombre = htmlspecialchars($_POST["nombre"]);
    $email = htmlspecialchars($_POST["email"]);
    echo "<h1>Datos recibidos</h1>";
    echo "<p>Nombre: " . $nombre . "</p>";
    echo "<p>Correo electrónico: " . $email . "</p>";
} else {
    echo "No se recibieron datos";
}
?>
