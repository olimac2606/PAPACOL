<?php
$numero = 3; // puede cambiar el numero para los diferentes casos

switch ($numero) {
    case 1:
        echo "El número es 1.";
        break;
    case 2:
        echo "El número es 2.";
        break;
    case 3:
        echo "El número es 3.";
        break;
    case 4:
        echo "El número es 4.";
        break;
    case 5:
        echo "El número es 5.";
        break;
    default:
        echo "Número no reconocido.";
        break;
}
?>
