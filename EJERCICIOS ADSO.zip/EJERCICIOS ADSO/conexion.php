<?php
// Declarar variables
$servidor = "localhost";
$usuario = "root";
$password = "123456789";
$baseDeDatos = "nombre_de_tu_base_de_datos"; // Cambia esto por el nombre de tu base de datos

// Realizar la conexión
$conexion = new mysqli($servidor, $usuario, $password, $baseDeDatos);

// Verificar la conexión
if ($conexion->connect_errno) {
    die("Conexión fallida: " . $conexion->connect_error);
}

echo "Conexión exitosa...";
?>

