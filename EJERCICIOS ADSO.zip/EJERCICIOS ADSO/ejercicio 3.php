<?php
$nombre = array ("ana", "Luis", "Pedro", "Maria", "Carlos");
foreach($nombre as $nombre){
    echo $nombre . "<br";
}
?>